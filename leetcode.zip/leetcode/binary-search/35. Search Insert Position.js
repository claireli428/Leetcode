/**
 * @param {number[]} nums
 * @param {number} target
 * @return {number}
 */
var searchInsert = function(nums, target) {
    //find by binary search
    //if exist, return middle
    //else it could only be before, middle, after start and end

};