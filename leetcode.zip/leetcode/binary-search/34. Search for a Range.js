/**
 * @param {number[]} nums
 * @param {number} target
 * @return {number[]}
 */


var searchRange = function(nums, target) {

   //find first target index;
        //normally, find first target, end while loop
        //here, since first target might not be first time it appears in the array
        //so, continue loop, move end point, until start is larger than or equals end
   // find last target index;
        //same as fine first index
   //
   // return [first, last];
};