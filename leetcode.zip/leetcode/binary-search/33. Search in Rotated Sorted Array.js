/**
 * @param {number[]} nums
 * @param {number} target
 * @return {number}
 */
var search = function(nums, target) {
    //first decide middle is above axis or below axis
    //if middle above axis, then decide if target is between start and middle, it is, keep binary searching, else drop subarray from start to middle
    //if middle below axis, then decide if target between middle and end, the same as above
};
