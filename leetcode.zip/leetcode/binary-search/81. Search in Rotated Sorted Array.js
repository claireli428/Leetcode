/**
 * @param {number[]} nums
 * @param {number} target
 * @return {boolean}
 */
var search = function(nums, target) {
    //duplicate
    //can't not drop subarray, move pointer one by one
};