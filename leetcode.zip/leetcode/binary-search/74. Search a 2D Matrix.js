/**
 * @param {number[][]} matrix
 * @param {number} target
 * @return {boolean}
 */
var searchMatrix = function(matrix, target) {
    //treat it as an sorted mxn array
    //use binary search
    //find middle, middle=mxn/2 row index = middle/n, col index = middle  mod m
}
;